
import * as z from 'zod';

// Form validation schema
export const bookingFormSchema = z.object({
  service: z.string({
    required_error: "Please select a service",
  }),
  date: z.date({
    required_error: "Please select a date",
  }),
  time: z.string({
    required_error: "Please select a time",
  }),
  petName: z.string().min(1, {
    message: "Pet name is required",
  }),
  petType: z.string().min(1, {
    message: "Pet type is required",
  }),
  name: z.string().min(1, {
    message: "Your name is required",
  }),
  email: z.string().email({
    message: "Please enter a valid email",
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number",
  }),
  notes: z.string().optional(),
});

export type BookingFormValues = z.infer<typeof bookingFormSchema>;
