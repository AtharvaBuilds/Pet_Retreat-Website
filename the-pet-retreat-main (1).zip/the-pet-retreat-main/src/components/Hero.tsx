
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Search, ArrowRight, Dog, Cat, Bird, Medal, Shield, Clock } from 'lucide-react';

const Hero = () => {
  const [selectedPet, setSelectedPet] = useState('dog');
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  return (
    <section className="relative min-h-screen pt-32 pb-20 px-4 overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-pet-softTeal/50 to-background"></div>
        <div className="circle-decoration top-40 left-1/4 w-72 h-72 bg-pet-teal/30 animate-pulse-slow"></div>
        <div className="circle-decoration bottom-40 right-1/4 w-80 h-80 bg-pet-orange/30 animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col space-y-8"
          >
            <div className="space-y-3">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="inline-block rounded-full bg-pet-coral/20 px-3 py-1 text-sm font-medium text-pet-coral"
              >
                Premium Pet Care Center
              </motion.div>
              <motion.h1
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-tight"
              >
                A Loving Home for Your <span className="text-pet-orange">Pets</span> – Veterinary, Boarding, Grooming & More!
              </motion.h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-lg md:text-xl text-muted-foreground max-w-lg"
              >
                Experience luxury pet care services at The Pet Retreat, where your furry family members receive the love and attention they deserve.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col space-y-5"
            >
              <div className="flex items-center bg-white/10 backdrop-blur-md rounded-full shadow-lg border border-white/20 overflow-hidden w-full max-w-xl">
                <div className="flex-shrink-0 pl-4">
                  <Search className="h-5 w-5 text-white/70" />
                </div>
                <input
                  type="text"
                  placeholder="Search for veterinary care, boarding, grooming..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full py-3 px-4 outline-none bg-transparent text-white placeholder:text-white/50"
                />
                <Button className="m-1 rounded-full bg-pet-coral hover:bg-pet-coral/90 px-4 py-2 text-white transition-all duration-200 btn-hover-effect">
                  Search
                </Button>
              </div>

              <div className="flex flex-wrap gap-3">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSelectedPet('dog')}
                    className={`pet-selection-btn ${selectedPet === 'dog' ? 'active' : ''}`}
                  >
                    <Dog className="h-4 w-4" />
                    <span>Dogs</span>
                  </button>
                  <button
                    onClick={() => setSelectedPet('cat')}
                    className={`pet-selection-btn ${selectedPet === 'cat' ? 'active' : ''}`}
                  >
                    <Cat className="h-4 w-4" />
                    <span>Cats</span>
                  </button>
                  <button
                    onClick={() => setSelectedPet('bird')}
                    className={`pet-selection-btn ${selectedPet === 'bird' ? 'active' : ''}`}
                  >
                    <Bird className="h-4 w-4" />
                    <span>Birds</span>
                  </button>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="flex flex-col sm:flex-row items-start sm:items-center gap-4"
            >
              <Button 
                size="lg" 
                className="bg-pet-coral hover:bg-pet-coral/90 text-white rounded-full btn-hover-effect"
                onClick={() => navigate('/booking')}
              >
                Book a Service <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="rounded-full border-pet-teal text-pet-teal hover:bg-pet-teal/10"
                onClick={() => {
                  const servicesSection = document.getElementById('services');
                  if (servicesSection) {
                    servicesSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Explore Services
              </Button>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="grid grid-cols-3 gap-4 mt-4"
            >
              <div className="flex items-center space-x-2">
                <div className="bg-pet-cream/20 backdrop-blur-md rounded-full p-2">
                  <Medal className="h-5 w-5 text-pet-orange" />
                </div>
                <span className="text-sm font-medium">Premium Care</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="bg-pet-cream/20 backdrop-blur-md rounded-full p-2">
                  <Shield className="h-5 w-5 text-pet-teal" />
                </div>
                <span className="text-sm font-medium">Certified Vets</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="bg-pet-cream/20 backdrop-blur-md rounded-full p-2">
                  <Clock className="h-5 w-5 text-pet-coral" />
                </div>
                <span className="text-sm font-medium">24/7 Service</span>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative lg:h-[450px] lg:w-[450px] mx-auto"
          >
            <div className="absolute inset-0 bg-gradient-radial from-pet-teal/40 to-transparent rounded-full animate-pulse-slow"></div>
            <img
              src={selectedPet === 'dog' ? "https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" : 
                   selectedPet === 'cat' ? "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1143&q=80" :
                   "https://images.unsplash.com/photo-1452570053594-1b985d6ea890?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=987&q=80"}
              alt="Pet"
              className="rounded-3xl object-cover h-full w-full shadow-2xl transition-all duration-500 img-fade-in"
            />
            <div className="absolute -bottom-10 left-1/2 transform -translate-x-1/2 glass-morphism px-8 py-5 rounded-2xl w-3/4 flex flex-col items-center">
              <p className="text-sm font-medium text-white/80">Trusted by</p>
              <div className="flex justify-between items-center w-full mt-3">
                <img src="https://img.icons8.com/color/96/null/royal-canin.png" alt="Royal Canin" className="h-6" />
                <img src="https://img.icons8.com/color/96/null/purina.png" alt="Purina" className="h-7" />
                <img src="https://img.icons8.com/color/96/null/pedigree.png" alt="Pedigree" className="h-6" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
