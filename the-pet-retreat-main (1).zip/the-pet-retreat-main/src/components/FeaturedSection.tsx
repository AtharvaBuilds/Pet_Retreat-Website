
import { motion } from 'framer-motion';
import { Clock, MapPin, Shield, ThumbsUp, CheckCircle, StarIcon, BadgeCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const FeaturedSection = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-pet-lightPurple/20">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="absolute -top-10 -left-10 w-64 h-64 bg-pet-softGreen rounded-full filter blur-3xl opacity-50 -z-10"></div>
              <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-pet-softBlue rounded-full filter blur-3xl opacity-50 -z-10"></div>
              
              <div className="relative z-10 rounded-3xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.unsplash.com/photo-1612536057832-2ff7ead58194?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
                  alt="Vet with dog at The Pet Retreat" 
                  className="w-full h-auto rounded-3xl object-cover img-fade-in"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <Badge variant="outline" className="bg-white/20 text-white border-none mb-2">Featured</Badge>
                    <h3 className="text-xl font-bold">State-of-the-art Facility</h3>
                    <p className="text-white/80">The Pet Retreat's main center in downtown</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -right-8 top-1/4 glass-card bg-white px-5 py-4 rounded-xl shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-pet-softBlue rounded-full p-2">
                    <Clock className="h-5 w-5 text-pet-blue" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Always Available</p>
                    <p className="text-xs text-muted-foreground">24/7 Emergency Care</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -left-8 bottom-1/4 glass-card bg-white px-5 py-4 rounded-xl shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-pet-softGreen rounded-full p-2">
                    <MapPin className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Central Location</p>
                    <p className="text-xs text-muted-foreground">Easy to reach</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
          
          <div className="order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <Badge variant="outline" className="border-pet-purple text-pet-purple px-4 py-1 text-sm">
                About Our Center
              </Badge>
              
              <h2 className="text-3xl sm:text-4xl font-bold leading-tight">
                Welcome to <span className="text-pet-purple">The Pet Retreat</span>, your pet's home away from home
              </h2>
              
              <p className="text-muted-foreground">
                Established in 2015, The Pet Retreat has been providing exceptional care for pets across the region. Our state-of-the-art facility is designed with your pets' comfort and wellbeing in mind.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-3">
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-pet-softGreen rounded-full p-1">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Certified Veterinarians</h4>
                    <p className="text-sm text-muted-foreground">Experienced and caring staff</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-pet-softBlue rounded-full p-1">
                    <Shield className="h-5 w-5 text-pet-blue" />
                  </div>
                  <div>
                    <h4 className="font-medium">Modern Equipment</h4>
                    <p className="text-sm text-muted-foreground">Latest technology for pet care</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-pet-softYellow rounded-full p-1">
                    <StarIcon className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Luxury Boarding</h4>
                    <p className="text-sm text-muted-foreground">Comfortable accommodations</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="mt-1 bg-pet-softPink rounded-full p-1">
                    <ThumbsUp className="h-5 w-5 text-pink-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Customer Satisfaction</h4>
                    <p className="text-sm text-muted-foreground">Rated 4.9/5 by pet owners</p>
                  </div>
                </div>
              </div>
              
              <div className="pt-4">
                <Button className="bg-pet-purple hover:bg-pet-purple/90 text-white rounded-full px-6 py-6 btn-hover-effect">
                  Tour Our Facility
                </Button>
              </div>
              
              <div className="flex items-center gap-4 pt-4">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map(id => (
                    <div key={id} className="w-10 h-10 rounded-full border-2 border-white overflow-hidden">
                      <img 
                        src={`https://randomuser.me/api/portraits/men/${20 + id}.jpg`} 
                        alt={`Staff member ${id}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map(star => (
                        <StarIcon key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="ml-2 text-sm font-medium">4.9/5</span>
                  </div>
                  <p className="text-xs text-muted-foreground">From 2,000+ happy clients</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedSection;
