
import { useFormContext } from 'react-hook-form';
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

interface TextareaFieldProps {
  name: string;
  label: string;
  placeholder: string;
  isRequired?: boolean;
}

const TextareaField = ({ name, label, placeholder, isRequired = false }: TextareaFieldProps) => {
  const { control } = useFormContext();

  return (
    <FormField
      control={control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel className="text-white">
            {label} {!isRequired && <span className="text-white/50">(Optional)</span>}
          </FormLabel>
          <FormControl>
            <textarea
              className="w-full min-h-[100px] rounded-md p-3 bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-petretreat-purple"
              placeholder={placeholder}
              {...field}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};

export default TextareaField;
