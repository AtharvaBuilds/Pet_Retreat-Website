
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { PawPrint, Clock } from 'lucide-react';
import { toast } from 'sonner';

import { Form } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { bookingFormSchema, BookingFormValues } from '@/lib/schemas/bookingSchema';
import { services, timeSlots } from '@/lib/constants/bookingConstants';
import SelectField from './SelectField';
import DatePickerField from './DatePickerField';
import InputField from './InputField';
import TextareaField from './TextareaField';

const BookingForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      notes: "",
    },
  });

  const onSubmit = async (values: BookingFormValues) => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    console.log(values);
    toast.success("Booking submitted successfully! We'll confirm your appointment shortly.", {
      duration: 5000,
    });
    
    setIsSubmitting(false);
    form.reset();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Service Selection */}
          <SelectField 
            name="service" 
            label="Select Service" 
            placeholder="Select a service" 
            options={services} 
          />

          {/* Date Picker */}
          <DatePickerField name="date" label="Date" />

          {/* Time Selection */}
          <SelectField 
            name="time" 
            label="Time" 
            placeholder="Select a time" 
            options={timeSlots.map(time => ({ name: time }))} 
          />

          {/* Pet Name */}
          <InputField 
            name="petName" 
            label="Pet's Name" 
            placeholder="Enter your pet's name" 
          />

          {/* Pet Type */}
          <InputField 
            name="petType" 
            label="Pet Type" 
            placeholder="Dog, Cat, Bird, etc." 
          />

          {/* Owner Name */}
          <InputField 
            name="name" 
            label="Your Name" 
            placeholder="Enter your name" 
          />

          {/* Email */}
          <InputField 
            name="email" 
            label="Email" 
            placeholder="your@email.com" 
            type="email" 
          />

          {/* Phone */}
          <InputField 
            name="phone" 
            label="Phone Number" 
            placeholder="Enter your phone number" 
          />
        </div>

        {/* Special Requirements */}
        <TextareaField 
          name="notes" 
          label="Special Requirements" 
          placeholder="Please let us know if you have any special requirements or notes for your booking" 
        />

        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="w-full bg-petretreat-purple hover:bg-petretreat-purple/90 text-white rounded-full py-6 transition-all duration-200 btn-hover-effect"
        >
          {isSubmitting ? (
            <span className="flex items-center">
              <span className="animate-spin mr-2">
                <Clock className="h-5 w-5" />
              </span>
              Processing...
            </span>
          ) : (
            <span className="flex items-center justify-center">
              Book Appointment
              <PawPrint className="ml-2 h-5 w-5" />
            </span>
          )}
        </Button>
      </form>
    </Form>
  );
};

export default BookingForm;
