
import { useState } from 'react';
import { motion } from 'framer-motion';
import { StarIcon, ArrowLeft, ArrowRight, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';

const testimonials = [
  {
    id: 1,
    name: "Jessica Wilson",
    pet: "Max, Golden Retriever",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    petImage: "https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    text: "The Pet Retreat has been a game-changer for me and Max. The veterinary care is top-notch, and the booking process is incredibly smooth. The platform's convenience has made pet care so much easier for us."
  },
  {
    id: 2,
    name: "Michael Chen",
    pet: "Luna, Domestic Shorthair Cat",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    petImage: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1143&q=80",
    text: "Luna can be quite picky with groomers, but through The Pet Retreat, we found a professional who knows exactly how to make her comfortable. The reviews were accurate and helpful in making our choice."
  },
  {
    id: 3,
    name: "Sarah Johnson",
    pet: "Charlie, Cockatiel",
    image: "https://randomuser.me/api/portraits/women/68.jpg",
    petImage: "https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1112&q=80",
    text: "Finding specialized care for Charlie was always challenging until I discovered The Pet Retreat. Their network of avian specialists has been incredible, and the online consultations have saved us so much time."
  }
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="py-20 px-4 bg-gradient-soft from-pet-softBlue/30 to-white">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block"
          >
            <Quote className="h-10 w-10 mx-auto text-pet-purple opacity-50 mb-4" />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold mb-4"
          >
            What Pet Parents Say
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Hear from our happy customers and their pets about their experiences with The Pet Retreat.
          </motion.p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <motion.div
              key={currentTestimonial.id + "-img"}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.5 }}
              className="col-span-5 flex justify-center"
            >
              <div className="relative">
                <div className="absolute -top-6 -left-6 w-40 h-40 bg-pet-softPink rounded-full filter blur-3xl opacity-50"></div>
                <div className="relative h-64 w-64 rounded-full p-3 bg-gradient-to-tr from-pet-purple to-pet-blue overflow-hidden">
                  <img 
                    src={currentTestimonial.petImage} 
                    alt={currentTestimonial.pet} 
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
              </div>
            </motion.div>

            <motion.div
              key={currentTestimonial.id + "-content"}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5 }}
              className="col-span-7 glass-card bg-white p-8"
            >
              <div className="flex mb-5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <StarIcon key={star} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              <blockquote className="text-lg mb-6">
                "{currentTestimonial.text}"
              </blockquote>

              <div className="flex items-center">
                <div className="h-12 w-12 rounded-full overflow-hidden mr-4">
                  <img 
                    src={currentTestimonial.image} 
                    alt={currentTestimonial.name} 
                    className="h-full w-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-semibold">{currentTestimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{currentTestimonial.pet}</p>
                </div>
              </div>

              <div className="mt-8 flex justify-between items-center">
                <div className="flex space-x-2">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentIndex(index)}
                      className={`w-2.5 h-2.5 rounded-full transition-all ${
                        index === currentIndex ? "bg-pet-purple w-8" : "bg-gray-300"
                      }`}
                      aria-label={`Go to testimonial ${index + 1}`}
                    />
                  ))}
                </div>

                <div className="flex space-x-3">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="rounded-full p-2 border-pet-purple text-pet-purple hover:bg-pet-lightPurple/50"
                    onClick={prevTestimonial}
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="rounded-full p-2 border-pet-purple text-pet-purple hover:bg-pet-lightPurple/50"
                    onClick={nextTestimonial}
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
