
import { motion } from 'framer-motion';
import { Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface ServiceDetailProps {
  id: string;
  title: string;
  description: string;
  details: string[];
  image: string;
  color: string;
  isEven: boolean;
}

const ServiceDetail = ({ 
  id, 
  title, 
  description, 
  details, 
  image, 
  color, 
  isEven 
}: ServiceDetailProps) => {
  return (
    <section id={id} className="py-20 px-4 relative">
      {/* Background decoration */}
      <div className={`absolute inset-0 ${isEven ? 'bg-petretreat-slate/30' : 'bg-transparent'} z-0`}></div>
      
      <div className="container mx-auto max-w-7xl relative z-10">
        <div className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-10 lg:gap-16`}>
          {/* Image */}
          <motion.div 
            initial={{ opacity: 0, x: isEven ? -50 : 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="w-full lg:w-1/2"
          >
            <div className="rounded-2xl overflow-hidden shadow-lg border border-white/10 h-[300px] md:h-[400px]">
              <img 
                src={image} 
                alt={title} 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
              />
            </div>
          </motion.div>
          
          {/* Content */}
          <motion.div 
            initial={{ opacity: 0, x: isEven ? 50 : -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="w-full lg:w-1/2"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">{title}</h2>
            <p className="text-lg text-white/80 mb-6">{description}</p>
            
            <div className="space-y-4 mb-8">
              {details.map((detail, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: 0.1 * index }}
                  className="flex items-start"
                >
                  <div className="rounded-full p-1 mr-3 mt-0.5" style={{ backgroundColor: color }}>
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <p className="text-white/80">{detail}</p>
                </motion.div>
              ))}
            </div>
            
            <div className="flex flex-wrap gap-3">
              <Link to={`/booking?service=${id}`}>
                <Button 
                  className="rounded-full" 
                  style={{ backgroundColor: color, borderColor: color }}
                >
                  Book This Service <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to={`/contact?inquiry=${id}`}>
                <Button variant="outline" className="rounded-full border-white/20 text-white">
                  Learn More
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ServiceDetail;
