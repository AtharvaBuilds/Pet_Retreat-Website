
import { motion } from 'framer-motion';
import { Search, CalendarDays, CheckCircle } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: "Find the perfect service",
    description: "Browse through our wide range of pet care services and providers to find what your pet needs.",
    icon: Search,
    color: "bg-pet-softBlue",
    textColor: "text-pet-blue"
  },
  {
    id: 2,
    title: "Book an appointment",
    description: "Select a convenient time and date for your pet's appointment directly through our platform.",
    icon: CalendarDays,
    color: "bg-pet-softGreen",
    textColor: "text-green-600"
  },
  {
    id: 3,
    title: "Enjoy premium pet care",
    description: "Relax knowing your pet is receiving the best care from certified professionals.",
    icon: CheckCircle,
    color: "bg-pet-lightPurple",
    textColor: "text-pet-purple"
  }
];

const HowItWorks = () => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold mb-4"
          >
            How The Pet Retreat Works
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            Quick and easy process to get the best care for your pet in just a few simple steps.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/4 left-0 right-0 h-0.5 bg-gradient-to-r from-pet-softBlue via-pet-softGreen to-pet-lightPurple" />

          {steps.map((step, index) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative z-10 flex flex-col items-center text-center px-4"
            >
              <div className={`${step.color} rounded-full p-5 mb-6 w-20 h-20 flex items-center justify-center shadow-lg`}>
                <step.icon className={`h-10 w-10 ${step.textColor}`} />
              </div>
              <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-white border border-gray-200 flex items-center justify-center text-sm font-bold">
                {step.id}
              </div>
              <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
