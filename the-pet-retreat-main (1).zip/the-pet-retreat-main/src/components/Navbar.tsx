
import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Phone, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import UserMenu from './UserMenu';
import { useIsMobile } from '@/hooks/use-mobile';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/services', label: 'Services' },
    { path: '/about', label: 'About Us' },
    { path: '/booking', label: 'Book Now' },
    { path: '/shop', label: 'Shop' },
    { path: '/contact', label: 'Contact' },
  ];

  return (
    <motion.header
      className={cn(
        'fixed w-full z-50 transition-all duration-300',
        isScrolled || isMenuOpen
          ? 'bg-white shadow-md'
          : 'bg-transparent'
      )}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className={`font-bold text-xl md:text-2xl ${isScrolled || isMenuOpen ? 'text-pet-charcoal' : 'text-pet-charcoal'}`}>
            <span className="text-pet-teal">The</span> Pet Retreat
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <ul className="flex items-center space-x-8">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className={cn(
                      'transition-colors hover:text-pet-coral',
                      (isScrolled || isMenuOpen) ? 'text-pet-charcoal' : 'text-pet-charcoal',
                      location.pathname === link.path && 'text-pet-coral font-medium'
                    )}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            
            <div className="flex items-center space-x-2">
              <Button 
                variant="ghost" 
                size="icon"
                className="text-pet-charcoal hover:text-pet-coral hover:bg-transparent"
                onClick={() => navigate('/shop/cart')}
              >
                <ShoppingCart className="h-5 w-5" />
              </Button>
              
              <Button 
                variant="outline" 
                size="sm"
                className="rounded-full border-pet-teal text-pet-teal hover:bg-pet-teal/10 hidden lg:flex items-center"
                onClick={() => navigate('/contact')}
              >
                <Phone className="mr-2 h-4 w-4" />
                Contact Us
              </Button>
              
              <UserMenu />
            </div>
          </nav>

          {/* Mobile Menu Toggle */}
          <div className="flex items-center md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              className="text-pet-charcoal hover:text-pet-coral hover:bg-transparent mr-2"
              onClick={() => navigate('/shop/cart')}
            >
              <ShoppingCart className="h-5 w-5" />
            </Button>
            
            <UserMenu />
            
            <Button
              variant="ghost"
              size="icon"
              className="ml-2 text-pet-charcoal hover:bg-transparent"
              onClick={toggleMenu}
              aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMenuOpen && isMobile && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-white"
          >
            <nav className="container mx-auto px-4 py-4">
              <ul className="flex flex-col space-y-4">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className={cn(
                        'block py-2 text-pet-charcoal hover:text-pet-coral transition-colors',
                        location.pathname === link.path && 'text-pet-coral font-medium'
                      )}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
                <li>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="w-full rounded-full border-pet-teal text-pet-teal hover:bg-pet-teal/10 flex items-center justify-center mt-2"
                    onClick={() => navigate('/contact')}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    Contact Us
                  </Button>
                </li>
              </ul>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

export default Navbar;
