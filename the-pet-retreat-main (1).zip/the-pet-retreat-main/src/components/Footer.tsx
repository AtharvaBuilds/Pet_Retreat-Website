
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, MapPin, Phone, PawPrint } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Footer = () => {
  return (
    <footer className="bg-petretreat-dark pt-16 pb-8 border-t border-petretreat-purple/20">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <Link to="/" className="text-2xl font-bold flex items-center space-x-2 mb-6">
              <span className="bg-petretreat-purple text-white p-1 rounded-md">
                <PawPrint className="h-6 w-6" />
              </span>
              <span className="text-white font-poppins">The <span className="text-petretreat-purple">Pet</span> Retreat</span>
            </Link>
            <p className="text-gray-300 mb-6">
              Your trusted destination for comprehensive pet care services. We provide specialized care for dogs, cats, and birds with a focus on health, comfort, and happiness.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="rounded-full hover:bg-petretreat-purple/20 text-petretreat-purple">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full hover:bg-petretreat-purple/20 text-petretreat-purple">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-full hover:bg-petretreat-purple/20 text-petretreat-purple">
                <Instagram className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-6 text-white">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/about" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Our Services
                </Link>
              </li>
              <li>
                <Link to="/team" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Meet Our Team
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Pet Care Tips
                </Link>
              </li>
              <li>
                <Link to="/faqs" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  FAQs
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-6 text-white">Our Services</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/services/veterinary" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Veterinary Care
                </Link>
              </li>
              <li>
                <Link to="/services/boarding" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Pet Boarding & Daycare
                </Link>
              </li>
              <li>
                <Link to="/services/grooming" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Grooming Services
                </Link>
              </li>
              <li>
                <Link to="/services/training" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Pet Training
                </Link>
              </li>
              <li>
                <Link to="/services/retail" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Pet Shop
                </Link>
              </li>
              <li>
                <Link to="/services/wellness" className="text-gray-300 hover:text-petretreat-purple transition-colors">
                  Wellness Programs
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-6 text-white">Visit Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-petretreat-purple mt-0.5 flex-shrink-0" />
                <span className="text-gray-300">
                  123 Pet Retreat Lane, Furry Heights, PR 54321, United States
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-petretreat-purple flex-shrink-0" />
                <span className="text-gray-300">+1 (555) 987-6543</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-petretreat-purple flex-shrink-0" />
                <span className="text-gray-300">info@thepetretreat.com</span>
              </li>
            </ul>

            <div className="mt-6">
              <h4 className="font-medium mb-3 text-white">Join our pet parent community</h4>
              <div className="flex space-x-2">
                <Input 
                  type="email" 
                  placeholder="Your email" 
                  className="rounded-full bg-petretreat-slate/50 border-petretreat-purple/20 focus-visible:ring-petretreat-purple text-white"
                />
                <Button className="rounded-full bg-petretreat-purple hover:bg-petretreat-purple/90 text-white btn-hover-effect">
                  Join
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-petretreat-purple/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} The Pet Retreat. All rights reserved.
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm">
            <Link to="/privacy" className="text-gray-400 hover:text-petretreat-purple transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-gray-400 hover:text-petretreat-purple transition-colors">
              Terms of Service
            </Link>
            <Link to="/cookies" className="text-gray-400 hover:text-petretreat-purple transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
