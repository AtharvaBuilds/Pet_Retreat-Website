
import { motion } from 'framer-motion';
import { ArrowRight, Stethoscope, Hotel, Scissors, Target, ShoppingBag, Video, Heart, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const services = [
  {
    id: 1,
    title: "Veterinary Care",
    icon: Stethoscope,
    description: "Our in-house 24/7 medical services include comprehensive checkups, surgeries, vaccinations, and emergency care.",
    bgColor: "bg-pet-teal",
    link: "/services/veterinary"
  },
  {
    id: 2,
    title: "Pet Boarding & Daycare",
    icon: Hotel,
    description: "Safe, personalized boarding with constant veterinary supervision in our spacious, climate-controlled facilities.",
    bgColor: "bg-pet-orange",
    link: "/services/boarding"
  },
  {
    id: 3,
    title: "Grooming & Hygiene",
    icon: Scissors,
    description: "Professional grooming, bathing, and parasite control services by our certified pet stylists.",
    bgColor: "bg-pet-coral",
    link: "/services/grooming"
  },
  {
    id: 4,
    title: "Pet Training",
    icon: Target,
    description: "Personalized obedience training, behavior modification, and socialization programs from our expert trainers.",
    bgColor: "bg-pet-teal",
    link: "/services/training"
  },
  {
    id: 5,
    title: "Retail Store",
    icon: ShoppingBag,
    description: "Premium pet food, toys, accessories, and health products available in our well-stocked on-site store.",
    bgColor: "bg-pet-orange",
    link: "/services/retail"
  },
  {
    id: 6,
    title: "Online Services",
    icon: Video,
    description: "Easy booking, teleconsultations with our vets, and live-stream monitoring of your boarded pets.",
    bgColor: "bg-pet-coral",
    link: "/services/online"
  },
  {
    id: 7,
    title: "Pet Wellness Programs",
    icon: Heart,
    description: "Exclusive spa treatments, rehabilitation, and wellness services for the complete wellbeing of your pets.",
    bgColor: "bg-pet-teal",
    link: "/services/wellness"
  },
  {
    id: 8,
    title: "Pet Taxi Service",
    icon: Car,
    description: "Safe and comfortable transportation for your pets to and from our facility, appointments, or other locations.",
    bgColor: "bg-pet-orange",
    link: "/services/taxi"
  }
];

const ServiceSection = () => {
  const navigate = useNavigate();
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="services" className="py-20 px-4 bg-gradient-to-b from-background to-muted">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block px-4 py-1 rounded-full bg-pet-softTeal text-pet-teal text-sm font-medium mb-4"
          >
            Our Services
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold mb-4"
          >
            The Pet Retreat's Complete Care Services
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-muted-foreground max-w-2xl mx-auto"
          >
            At The Pet Retreat, we provide all the care your pets need under one roof. Our center offers a comprehensive range of services designed specifically for the health and happiness of your furry family members.
          </motion.p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12"
        >
          {services.map((service) => (
            <motion.div
              key={service.id}
              variants={cardVariants}
              className="glass-morphism rounded-2xl p-6 transition-all hover:shadow-lg hover:-translate-y-1 flex flex-col"
            >
              <div className={`${service.bgColor} text-white rounded-full p-4 w-16 h-16 flex items-center justify-center mb-4`}>
                <service.icon className="h-8 w-8 text-white service-icon" />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">{service.title}</h3>
              <p className="text-white/70 mb-5 flex-grow">{service.description}</p>
              <Button 
                variant="ghost" 
                className="self-start flex items-center font-medium text-pet-coral hover:text-pet-coral/80 hover:bg-pet-coral/10 p-0 group"
                onClick={() => navigate(service.link)}
              >
                Learn more 
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-12">
          <p className="text-lg text-white/90 mb-6">Experience The Pet Retreat difference - where your pets receive the care they deserve.</p>
          <Button 
            size="lg" 
            className="bg-pet-coral hover:bg-pet-coral/90 text-white rounded-full transition-all duration-300 btn-hover-effect"
            onClick={() => navigate('/booking')}
          >
            Book an Appointment <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServiceSection;
