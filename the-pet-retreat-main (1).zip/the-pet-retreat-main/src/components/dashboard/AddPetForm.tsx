
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const petSchema = z.object({
  name: z.string().min(1, "Pet name is required"),
  type: z.string().min(1, "Pet type is required"),
  breed: z.string().min(1, "Breed is required"),
  age: z.preprocess(
    (a) => parseInt(z.string().parse(a), 10),
    z.number().positive("Age must be a positive number")
  ),
  weight: z.preprocess(
    (a) => parseFloat(z.string().parse(a)),
    z.number().positive("Weight must be a positive number").optional()
  ),
  gender: z.string().min(1, "Gender is required"),
  microchip: z.string().optional(),
});

type PetFormValues = z.infer<typeof petSchema>;

interface AddPetFormProps {
  onSuccess: () => void;
}

const AddPetForm = ({ onSuccess }: AddPetFormProps) => {
  const { user } = useAuth();
  const form = useForm<PetFormValues>({
    resolver: zodResolver(petSchema),
    defaultValues: {
      name: "",
      type: "",
      breed: "",
      gender: "",
    },
  });

  const onSubmit = async (data: PetFormValues) => {
    if (!user) {
      toast.error("You must be logged in to add a pet");
      return;
    }
    
    try {
      // Save to Supabase
      const { error } = await supabase
        .from('pets')
        .insert({
          user_id: user.id,
          name: data.name,
          type: data.type,
          breed: data.breed,
          age: data.age,
          notes: `Gender: ${data.gender}${data.microchip ? `, Microchip: ${data.microchip}` : ''}${data.weight ? `, Weight: ${data.weight}kg` : ''}`,
        });
      
      if (error) {
        console.error("Error adding pet:", error);
        toast.error("Failed to add pet. Please try again.");
        return;
      }
      
      onSuccess();
    } catch (error) {
      console.error("Error adding pet:", error);
      toast.error("Failed to add pet. Please try again.");
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Pet Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter your pet's name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Pet Type</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Dog">Dog</SelectItem>
                    <SelectItem value="Cat">Cat</SelectItem>
                    <SelectItem value="Bird">Bird</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="gender"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Gender</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="breed"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Breed</FormLabel>
              <FormControl>
                <Input placeholder="Enter breed" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="age"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Age (years)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="Age in years"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="weight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Weight (kg)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="Optional"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="microchip"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Microchip Number (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="Microchip ID" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button type="button" variant="outline" onClick={onSuccess}>
            Cancel
          </Button>
          <Button type="submit" className="bg-pet-teal hover:bg-pet-teal/90">
            Add Pet
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default AddPetForm;
