
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Bell, Calendar, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DashboardHeader = () => {
  const { user } = useAuth();
  
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  return (
    <div className="bg-card rounded-xl p-6 shadow-lg">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-r from-pet-teal to-pet-blue flex items-center justify-center text-white text-2xl font-bold overflow-hidden">
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <span>{profile?.first_name?.charAt(0) || user?.email?.charAt(0)?.toUpperCase()}</span>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold">
              Welcome, {profile?.first_name || user?.email?.split('@')[0]}!
            </h1>
            <p className="text-muted-foreground">
              Manage your pet profiles and appointments
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="icon" className="rounded-full">
            <Bell size={18} />
          </Button>
          <Button variant="outline" size="icon" className="rounded-full">
            <MessageCircle size={18} />
          </Button>
          <Button className="rounded-full bg-pet-teal hover:bg-pet-teal/90">
            <Calendar className="mr-2 h-4 w-4" />
            Book a Service
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DashboardHeader;
