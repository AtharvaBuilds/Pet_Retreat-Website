
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Dog, Cat, Bird, Edit, Trash2, PawPrint } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';
import AddPetForm from './AddPetForm';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

// Pet type definition
type Pet = {
  id: string;
  name: string;
  type: string;
  breed: string;
  age: number;
  image_url: string | null;
  user_id: string;
};

const PetProfiles = () => {
  const { user } = useAuth();
  const [isAddPetOpen, setIsAddPetOpen] = useState(false);
  const [isEditPetOpen, setIsEditPetOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentPet, setCurrentPet] = useState<Pet | null>(null);
  const queryClient = useQueryClient();
  
  // Fetch pets from Supabase
  const { data: pets = [], isLoading } = useQuery({
    queryKey: ['pets', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('pets')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) {
        toast.error('Failed to load pets');
        console.error('Error fetching pets:', error);
        return [];
      }
      
      return data as Pet[];
    },
    enabled: !!user?.id,
  });

  // Delete pet mutation
  const deletePetMutation = useMutation({
    mutationFn: async (petId: string) => {
      const { error } = await supabase
        .from('pets')
        .delete()
        .eq('id', petId)
        .eq('user_id', user?.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pets', user?.id] });
      toast.success('Pet profile deleted successfully');
      setIsDeleteDialogOpen(false);
      setCurrentPet(null);
    },
    onError: (error) => {
      toast.error('Failed to delete pet');
      console.error('Error deleting pet:', error);
    }
  });

  const handleDelete = (pet: Pet) => {
    setCurrentPet(pet);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (currentPet) {
      deletePetMutation.mutate(currentPet.id);
    }
  };

  const handleEdit = (pet: Pet) => {
    setCurrentPet(pet);
    setIsEditPetOpen(true);
  };

  const getPetIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'dog':
        return <Dog className="h-5 w-5 text-pet-teal" />;
      case 'cat':
        return <Cat className="h-5 w-5 text-pet-orange" />;
      case 'bird':
        return <Bird className="h-5 w-5 text-pet-coral" />;
      default:
        return <PawPrint className="h-5 w-5 text-pet-blue" />;
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">My Pets</h2>
          <Dialog open={isAddPetOpen} onOpenChange={setIsAddPetOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-full bg-pet-teal hover:bg-pet-teal/90">
                <Plus className="mr-2 h-4 w-4" />
                Add Pet
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add a New Pet</DialogTitle>
                <DialogDescription>
                  Add your pet's details to keep track of their care needs and preferences.
                </DialogDescription>
              </DialogHeader>
              <AddPetForm onSuccess={() => {
                setIsAddPetOpen(false);
                queryClient.invalidateQueries({ queryKey: ['pets', user?.id] });
                toast.success('Pet added successfully!');
              }} />
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-40">
            <div className="h-10 w-10 border-4 border-t-pet-teal border-r-transparent border-b-pet-orange border-l-transparent rounded-full animate-spin"></div>
          </div>
        ) : pets.length === 0 ? (
          <div className="text-center p-8 border border-dashed border-muted-foreground/50 rounded-xl">
            <PawPrint className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-medium mb-2">No pets added yet</h3>
            <p className="text-muted-foreground mb-4">Add your furry, feathery, or scaly friends to get started!</p>
            <Button 
              variant="outline" 
              onClick={() => setIsAddPetOpen(true)}
              className="rounded-full"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add your first pet
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pets.map((pet) => (
              <div key={pet.id} className="bg-card/50 rounded-xl p-4 shadow border border-border/50 hover:shadow-md transition-shadow">
                <div className="flex space-x-4">
                  <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                    {pet.image_url ? (
                      <img src={pet.image_url} alt={pet.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-pet-teal/20 flex items-center justify-center">
                        {getPetIcon(pet.type)}
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h3 className="font-semibold text-lg">{pet.name}</h3>
                      <div className="flex space-x-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleEdit(pet)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive"
                          onClick={() => handleDelete(pet)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      {getPetIcon(pet.type)}
                      <span>{pet.type}, {pet.breed}</span>
                    </div>
                    <div className="text-sm mt-1">{pet.age} {pet.age === 1 ? 'year' : 'years'} old</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Delete confirmation dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {currentPet?.name}'s profile. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit pet dialog - placeholder for now */}
      <Dialog open={isEditPetOpen} onOpenChange={setIsEditPetOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Pet Profile</DialogTitle>
          </DialogHeader>
          <p className="text-center py-4">Edit pet functionality would go here</p>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsEditPetOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default PetProfiles;
