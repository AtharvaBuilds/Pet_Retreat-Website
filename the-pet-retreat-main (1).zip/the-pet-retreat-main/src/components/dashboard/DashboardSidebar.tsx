
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Calendar, 
  Home, 
  PawPrint, 
  ShoppingBag, 
  FileText, 
  Settings, 
  LogOut,
  Video,
  Medal
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const DashboardSidebar = ({ activeTab, setActiveTab }) => {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
      toast.success('Successfully signed out');
    } catch (error) {
      toast.error('Error signing out');
      console.error('Error signing out:', error);
    }
  };

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: Home },
    { id: 'pets', label: 'My Pets', icon: PawPrint, highlighted: true },
    { id: 'appointments', label: 'Appointments', icon: Calendar },
    { id: 'monitoring', label: 'Live Monitoring', icon: Video },
    { id: 'shop', label: 'Pet Shop', icon: ShoppingBag },
    { id: 'records', label: 'Health Records', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="bg-card rounded-xl p-4 lg:p-6 shadow-lg h-fit">
      <h2 className="text-lg font-semibold mb-4">Dashboard</h2>
      <nav className="space-y-1">
        {menuItems.map((item) => (
          <Button
            key={item.id}
            variant={activeTab === item.id ? "secondary" : "ghost"}
            className={`w-full justify-start ${
              activeTab === item.id ? "bg-pet-teal/10 text-pet-teal" : ""
            } ${item.highlighted ? "border-l-4 border-pet-teal pl-[14px]" : ""}`}
            onClick={() => setActiveTab(item.id)}
          >
            <item.icon className={`mr-2 h-4 w-4 ${item.highlighted && activeTab !== item.id ? "text-pet-teal" : ""}`} />
            {item.label}
            {item.highlighted && <Medal className="ml-auto h-3 w-3 text-pet-coral" />}
          </Button>
        ))}
        
        <Button
          variant="ghost"
          className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={handleSignOut}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </nav>
    </div>
  );
};

export default DashboardSidebar;
