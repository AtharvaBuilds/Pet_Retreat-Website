
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Heart, VideoIcon, FileText } from 'lucide-react';

// Mock data for initial development
const MOCK_UPDATES = [
  {
    id: 1,
    petName: 'Buddy',
    date: '2023-11-14',
    time: '2:30 PM',
    update: 'Buddy had a great day at daycare! He played with several other dogs and enjoyed outdoor time. His appetite was good and he drank plenty of water.',
    staff: 'Emma Wilson',
    type: 'daily'
  },
  {
    id: 2,
    petName: 'Whiskers',
    date: '2023-11-14',
    time: '4:15 PM',
    update: 'Whiskers has been groomed today. We trimmed nails, cleaned ears, and gave a full bath. She was very cooperative and is looking beautiful!',
    staff: 'Michael Chen',
    type: 'grooming'
  }
];

const WellnessUpdates = () => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      month: 'short', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Wellness Updates</h2>
          <Button variant="outline" size="sm" className="rounded-full">
            View All
          </Button>
        </div>

        <Tabs defaultValue="updates">
          <TabsList className="mb-4">
            <TabsTrigger value="updates">Daily Updates</TabsTrigger>
            <TabsTrigger value="monitoring">Live Monitoring</TabsTrigger>
            <TabsTrigger value="reports">Health Reports</TabsTrigger>
          </TabsList>
          
          <TabsContent value="updates" className="space-y-4">
            {MOCK_UPDATES.map((update) => (
              <div key={update.id} className="p-4 rounded-lg border border-border bg-card/50">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-pet-teal/10 flex items-center justify-center">
                    <Heart className="h-5 w-5 text-pet-teal" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h3 className="font-medium">{update.petName}'s Update</h3>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(update.date)} at {update.time}
                      </span>
                    </div>
                    
                    <p className="mt-2 text-sm">{update.update}</p>
                    
                    <div className="mt-3 text-xs text-muted-foreground">
                      Provided by: {update.staff}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="monitoring">
            <div className="rounded-lg border border-border bg-card/50 p-6 text-center">
              <VideoIcon className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 font-medium">Live Monitoring</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Connect to our live camera feed to check on your pet while they're in our care.
              </p>
              <Button className="mt-4 bg-pet-coral hover:bg-pet-coral/90">
                Connect to Live Feed
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="reports">
            <div className="rounded-lg border border-border bg-card/50 p-6 text-center">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 font-medium">Health Reports</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                View detailed health reports and veterinary records for your pets.
              </p>
              <Button className="mt-4">
                View Health Reports
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default WellnessUpdates;
