
import { Calendar, Clock, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

// Mock data for initial development
const MOCK_APPOINTMENTS = [
  {
    id: 1,
    service: 'Veterinary Check-up',
    date: '2023-11-15',
    time: '10:00 AM',
    petName: 'Buddy',
    location: 'Main Clinic',
    status: 'confirmed'
  },
  {
    id: 2,
    service: 'Grooming Session',
    date: '2023-11-18',
    time: '2:30 PM',
    petName: 'Whiskers',
    location: 'Main Clinic',
    status: 'pending'
  }
];

const UpcomingAppointments = () => {
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800/30 dark:text-gray-400';
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Upcoming Appointments</h2>
          <Button className="rounded-full">
            View All
          </Button>
        </div>

        {MOCK_APPOINTMENTS.length > 0 ? (
          <div className="space-y-4">
            {MOCK_APPOINTMENTS.map((appointment) => (
              <div 
                key={appointment.id} 
                className="flex flex-col md:flex-row md:items-center justify-between p-4 rounded-lg border border-border bg-card/50 hover:bg-card/80 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4 md:mb-0">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-pet-coral/10 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-pet-coral" />
                  </div>
                  
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">{appointment.service}</h3>
                      <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${getStatusBadgeClass(appointment.status)}`}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">For {appointment.petName}</p>
                    <div className="flex flex-wrap items-center mt-1 text-sm text-muted-foreground gap-3">
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-3.5 w-3.5" />
                        {formatDate(appointment.date)}
                      </div>
                      <div className="flex items-center">
                        <Clock className="mr-1 h-3.5 w-3.5" />
                        {appointment.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="mr-1 h-3.5 w-3.5" />
                        {appointment.location}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    Reschedule
                  </Button>
                  <Button variant="outline" size="sm" className="text-destructive border-destructive hover:bg-destructive/10">
                    Cancel
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No upcoming appointments.</p>
            <Button className="mt-4 bg-pet-teal hover:bg-pet-teal/90">
              Book Now
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UpcomingAppointments;
