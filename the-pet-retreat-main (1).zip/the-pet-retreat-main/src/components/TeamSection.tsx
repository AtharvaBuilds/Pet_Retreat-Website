
import { motion } from 'framer-motion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Linkedin, Mail } from 'lucide-react';

const teamMembers = [
  {
    id: 1,
    name: "Manas Girish Kulkarni",
    role: "Veterinary Director",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    bio: "Specialized in small animal care with over 10 years of experience in veterinary medicine.",
    social: {
      email: "manas@thepetretreat.com",
      linkedin: "https://linkedin.com"
    }
  },
  {
    id: 2,
    name: "Atharva Rajendra Joshi",
    role: "Head of Grooming Services",
    image: "https://randomuser.me/api/portraits/men/42.jpg",
    bio: "Professional pet groomer with special expertise in breed-specific styling and gentle handling techniques.",
    social: {
      email: "atharva.joshi@thepetretreat.com",
      linkedin: "https://linkedin.com"
    }
  },
  {
    id: 3,
    name: "Atharva Vinayak Maslekar",
    role: "Training Specialist",
    image: "https://randomuser.me/api/portraits/men/62.jpg",
    bio: "Certified animal behaviorist specializing in obedience training and behavior modification for all breeds.",
    social: {
      email: "atharva.maslekar@thepetretreat.com",
      linkedin: "https://linkedin.com"
    }
  },
  {
    id: 4,
    name: "Atharva Santosh Suryavanshi",
    role: "Boarding & Daycare Manager",
    image: "https://randomuser.me/api/portraits/men/72.jpg",
    bio: "Passionate about creating a home-away-from-home environment for pets during their stay at The Pet Retreat.",
    social: {
      email: "atharva.suryavanshi@thepetretreat.com",
      linkedin: "https://linkedin.com"
    }
  }
];

const TeamSection = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-muted to-background relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="circle-decoration top-20 right-10 w-[300px] h-[300px] bg-pet-purple/10 animate-pulse-slow"></div>
        <div className="circle-decoration bottom-40 left-20 w-[400px] h-[400px] bg-pet-blue/10 animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
      </div>
      
      <div className="container mx-auto max-w-7xl relative z-10">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block px-4 py-1 rounded-full bg-pet-softPurple text-pet-purple text-sm font-medium mb-4"
          >
            Our Experts
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold mb-4 text-white"
          >
            Meet The Pet Retreat Team
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-white/70 max-w-2xl mx-auto"
          >
            Our dedicated professionals are committed to providing the highest quality care for your beloved pets.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden glass-morphism border-none shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80 z-10"></div>
                  <div className="pt-6 pb-20 flex justify-center relative z-0">
                    <Avatar className="h-40 w-40 border-4 border-white/10 shadow-lg">
                      <AvatarImage src={member.image} alt={member.name} />
                      <AvatarFallback className="text-3xl bg-pet-teal">
                        {member.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="absolute bottom-4 left-0 right-0 z-20 px-6 text-center">
                    <h3 className="text-xl font-bold text-white">{member.name}</h3>
                    <p className="text-white/80 text-sm">{member.role}</p>
                  </div>
                </div>
                <CardContent className="pt-6">
                  <p className="text-white/70 text-sm mb-4">{member.bio}</p>
                  <div className="flex justify-center space-x-3">
                    <a href={`mailto:${member.social.email}`} className="p-2 bg-pet-purple/20 rounded-full hover:bg-pet-purple transition-colors">
                      <Mail className="h-4 w-4 text-pet-purple hover:text-white" />
                    </a>
                    <a href={member.social.linkedin} target="_blank" rel="noopener noreferrer" className="p-2 bg-pet-blue/20 rounded-full hover:bg-pet-blue transition-colors">
                      <Linkedin className="h-4 w-4 text-pet-blue hover:text-white" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default TeamSection;
