
import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import ServiceSection from '@/components/ServiceSection';
import FeaturedSection from '@/components/FeaturedSection';
import HowItWorks from '@/components/HowItWorks';
import TeamSection from '@/components/TeamSection';
import Testimonials from '@/components/Testimonials';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';

const Index = () => {
  useEffect(() => {
    document.title = "The Pet Retreat | Your Premium Pet Care Center";
    window.scrollTo(0, 0);
  }, []);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
      >
        <div className="absolute inset-0 pointer-events-none overflow-hidden -z-10">
          <div className="circle-decoration top-20 left-10 w-[500px] h-[500px] bg-pet-teal/5 animate-pulse-slow"></div>
          <div className="circle-decoration bottom-40 right-20 w-[600px] h-[600px] bg-pet-orange/5 animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
          <div className="circle-decoration top-1/3 right-1/4 w-[400px] h-[400px] bg-pet-coral/5 animate-pulse-slow" style={{ animationDelay: '3s' }}></div>
        </div>
        
        <Navbar />
        <main className="flex-grow">
          <Hero />
          <ServiceSection />
          <FeaturedSection />
          <HowItWorks />
          <TeamSection />
          <Testimonials />
          <CTASection />
        </main>
        <Footer />
      </motion.div>
    </AnimatePresence>
  );
};

export default Index;
