
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Stethoscope, 
  Hotel, 
  Scissors, 
  Target, 
  ShoppingBag, 
  Video, 
  Heart, 
  Car,
  ArrowRight,
  CalendarClock
} from 'lucide-react';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import ServiceDetail from '@/components/ServiceDetail';

// Service data with detailed information
const services = [
  {
    id: "veterinary",
    title: "Veterinary Care",
    icon: Stethoscope,
    color: "#2A9D8F", // Using the deep teal from your color palette
    description: "Our state-of-the-art veterinary services provide comprehensive healthcare for your beloved pets.",
    details: [
      "Comprehensive health check-ups and vaccinations",
      "Advanced diagnostic services with in-house laboratory",
      "Specialized surgery and recovery care",
      "Dental care and preventative treatments",
      "Emergency services available 24/7"
    ],
    image: "https://images.unsplash.com/photo-1583301286816-f4f05e1e8b25?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
  },
  {
    id: "boarding",
    title: "Pet Boarding & Daycare",
    icon: Hotel,
    color: "#F4A261", // Using the soft pastel orange
    description: "Safe, comfortable, and supervised accommodation for your pets while you're away.",
    details: [
      "Spacious and climate-controlled living spaces",
      "Personalized care plans for each pet",
      "Regular playtime and exercise schedules",
      "24/7 monitoring by trained professionals",
      "Custom meal plans following your pet's diet"
    ],
    image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2369&q=80"
  },
  {
    id: "grooming",
    title: "Grooming & Hygiene",
    icon: Scissors,
    color: "#2A9D8F", // Deep teal
    description: "Professional grooming services to keep your pet clean, healthy, and looking their best.",
    details: [
      "Breed-specific haircuts and styling",
      "Relaxing bathing and coat treatments",
      "Nail trimming and paw care",
      "Ear cleaning and dental hygiene",
      "Specialized treatments for skin conditions"
    ],
    image: "https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2574&q=80"
  },
  {
    id: "training",
    title: "Pet Training",
    icon: Target,
    color: "#F4A261", // Soft pastel orange
    description: "Expert training programs to help your pet develop good behavior and social skills.",
    details: [
      "Basic obedience training for all ages",
      "Behavior modification for specific issues",
      "Puppy and kitten socialization classes",
      "Advanced command training",
      "One-on-one sessions with certified trainers"
    ],
    image: "https://images.unsplash.com/photo-1558929996-da64ba858215?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2173&q=80"
  },
  {
    id: "retail",
    title: "Retail Store",
    icon: ShoppingBag,
    color: "#2A9D8F", // Deep teal
    description: "Premium pet supplies including food, toys, beds, and health products.",
    details: [
      "High-quality pet food for all dietary needs",
      "Durable toys and enrichment items",
      "Comfortable beds and home accessories",
      "Health supplements and medications",
      "Pet travel essentials and safety equipment"
    ],
    image: "https://images.unsplash.com/photo-1516750105099-4b8a83e217ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2370&q=80"
  },
  {
    id: "telehealth",
    title: "Online Consultation",
    icon: Video,
    color: "#F4A261", // Soft pastel orange
    description: "Virtual veterinary care from the comfort of your home via video calls.",
    details: [
      "Convenient video consultations with licensed veterinarians",
      "Follow-up care and monitoring of existing conditions",
      "Prescription refills and treatment adjustments",
      "Behavioral advice and nutritional counseling",
      "Easy scheduling through our online portal"
    ],
    image: "https://images.unsplash.com/photo-1581888227599-779811939961?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2274&q=80"
  },
  {
    id: "wellness",
    title: "Pet Wellness Programs",
    icon: Heart,
    color: "#2A9D8F", // Deep teal
    description: "Comprehensive wellness plans for the overall health and longevity of your pets.",
    details: [
      "Customized wellness programs for different life stages",
      "Regular health assessments and preventative care",
      "Nutritional counseling and weight management",
      "Parasite prevention and control",
      "Senior pet care and chronic disease management"
    ],
    image: "https://images.unsplash.com/photo-1604848698030-c434ba08ece1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2574&q=80"
  },
  {
    id: "taxi",
    title: "Pet Taxi Service",
    icon: Car,
    color: "#F4A261", // Soft pastel orange
    description: "Safe and convenient transportation service for your pets.",
    details: [
      "Reliable pick-up and drop-off to any destination",
      "Climate-controlled vehicles for maximum comfort",
      "Trained drivers experienced in pet handling",
      "Secure carriers and safety equipment",
      "Tracking system to monitor your pet's journey"
    ],
    image: "https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2370&q=80"
  }
];

const Services = () => {
  useEffect(() => {
    document.title = "Our Services | The Pet Retreat";
    window.scrollTo(0, 0);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-28 pb-20">
        {/* Hero Section */}
        <section className="px-4 mb-20">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-10">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-4xl md:text-5xl font-bold mb-6 text-white"
              >
                Premium Pet Care Services
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto"
              >
                At The Pet Retreat, we provide comprehensive care services tailored to your pet's specific needs. 
                Discover our range of premium offerings designed to keep your furry family members happy and healthy.
              </motion.p>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5"
            >
              {services.map((service, index) => (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 * index }}
                  className="glass-card p-6 flex flex-col items-center text-center group cursor-pointer"
                  onClick={() => document.getElementById(service.id)?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <div 
                    className={`rounded-full p-4 mb-4 transition-all duration-300 group-hover:scale-110`}
                    style={{ backgroundColor: service.color }}
                  >
                    <service.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-white">{service.title}</h3>
                  <p className="text-white/70 text-sm mb-4">{service.description}</p>
                  <span className="text-[#F4A261] font-medium flex items-center text-sm mt-auto">
                    Learn more <ArrowRight className="ml-1 h-4 w-4" />
                  </span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Detailed Service Sections */}
        {services.map((service, index) => (
          <ServiceDetail 
            key={service.id}
            id={service.id}
            title={service.title}
            description={service.description}
            details={service.details}
            image={service.image}
            color={service.color}
            isEven={index % 2 === 0}
          />
        ))}

        {/* Call to Action */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-7xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#2A9D8F] to-[#264653] p-10 md:p-16"
            >
              {/* Background decorative elements */}
              <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full filter blur-3xl -translate-y-1/2 translate-x-1/4"></div>
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-white/5 rounded-full filter blur-3xl translate-y-1/2 -translate-x-1/4"></div>
              
              <div className="relative z-10 text-center max-w-3xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                  Ready to Experience Premium Pet Care?
                </h2>
                <p className="text-white/90 mb-8 text-lg">
                  Book your pet's first appointment today and discover why we're the trusted choice for comprehensive pet care. Our expert team is ready to provide personalized attention to your beloved companions.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <Link to="/booking">
                    <Button size="lg" className="bg-[#E76F51] hover:bg-[#E76F51]/90 text-white rounded-full btn-hover-effect">
                      Book an Appointment <CalendarClock className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                  <Link to="/contact">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 rounded-full">
                      Contact Us
                    </Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </motion.div>
  );
};

export default Services;
