
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const Contact = () => {
  useEffect(() => {
    document.title = "Contact Us | The Pet Retreat";
    window.scrollTo(0, 0);
  }, []);

  const contactInfo = [
    {
      icon: <MapPin className="h-6 w-6 text-petretreat-coral" />,
      title: "Visit Us",
      details: "123 Pet Retreat Lane, Furry Heights, PR 54321, United States"
    },
    {
      icon: <Phone className="h-6 w-6 text-petretreat-orange" />,
      title: "Call Us",
      details: "+1 (555) 987-6543"
    },
    {
      icon: <Mail className="h-6 w-6 text-petretreat-teal" />,
      title: "Email Us",
      details: "info@thepetretreat.com"
    },
    {
      icon: <Clock className="h-6 w-6 text-petretreat-purple" />,
      title: "Opening Hours",
      details: "Monday - Sunday: 8:00 AM - 8:00 PM"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <section className="py-20">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-16">
              <div className="inline-block rounded-full bg-petretreat-orange/20 px-3 py-1 text-sm font-medium text-petretreat-orange mb-3">
                Get In Touch
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-shadow">
                Contact Us
              </h1>
              <p className="text-lg text-petretreat-lightGray max-w-3xl mx-auto">
                We're here to help with any questions about our pet care services. Reach out to us and we'll respond as soon as possible.
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 mb-16">
              <div className="lg:col-span-2 space-y-6">
                {contactInfo.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="neo-card rounded-xl p-5 flex items-start gap-4"
                  >
                    <div className="bg-petretreat-darkCharcoal p-2 rounded-full neo-button">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-1">{item.title}</h3>
                      <p className="text-petretreat-lightGray">{item.details}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <div className="lg:col-span-3 glass-morphism rounded-2xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Send Us a Message</h2>
                <form className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="name" className="block text-petretreat-lightGray mb-2">Your Name</label>
                      <Input 
                        id="name" 
                        placeholder="Enter your name" 
                        className="bg-petretreat-darkCharcoal border-petretreat-darkPurple/30 text-white placeholder:text-petretreat-lightGray/50"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-petretreat-lightGray mb-2">Your Email</label>
                      <Input 
                        id="email" 
                        type="email" 
                        placeholder="Enter your email" 
                        className="bg-petretreat-darkCharcoal border-petretreat-darkPurple/30 text-white placeholder:text-petretreat-lightGray/50"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-petretreat-lightGray mb-2">Subject</label>
                    <Input 
                      id="subject" 
                      placeholder="How can we help you?" 
                      className="bg-petretreat-darkCharcoal border-petretreat-darkPurple/30 text-white placeholder:text-petretreat-lightGray/50"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-petretreat-lightGray mb-2">Message</label>
                    <Textarea 
                      id="message" 
                      placeholder="Type your message here..." 
                      rows={5}
                      className="bg-petretreat-darkCharcoal border-petretreat-darkPurple/30 text-white placeholder:text-petretreat-lightGray/50"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="bg-petretreat-coral hover:bg-petretreat-coral/90 text-white w-full sm:w-auto"
                  >
                    <Send className="mr-2 h-4 w-4" /> Send Message
                  </Button>
                </form>
              </div>
            </div>
            
            <div className="neo-card rounded-2xl overflow-hidden h-96">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30591910525!2d-74.25986432970721!3d40.69714941680757!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2suk!4v1650290740564!5m2!1sen!2suk" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="The Pet Retreat Location"
              ></iframe>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </motion.div>
  );
};

export default Contact;
