
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import DashboardHeader from '@/components/dashboard/DashboardHeader';
import DashboardSidebar from '@/components/dashboard/DashboardSidebar';
import PetProfiles from '@/components/dashboard/PetProfiles';
import UpcomingAppointments from '@/components/dashboard/UpcomingAppointments';
import WellnessUpdates from '@/components/dashboard/WellnessUpdates';

const Dashboard = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    document.title = "My Dashboard | The Pet Retreat";
    
    // If not logged in and not loading, redirect to auth page
    if (!isLoading && !user) {
      navigate('/auth');
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="h-16 w-16 relative">
          <div className="h-full w-full rounded-full border-4 border-t-pet-teal border-b-pet-orange border-l-pet-coral border-r-pet-cream animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="h-8 w-8 bg-white rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  const renderActiveContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <>
            <PetProfiles />
            <UpcomingAppointments />
            <WellnessUpdates />
          </>
        );
      case 'pets':
        return <PetProfiles />;
      case 'appointments':
        return <UpcomingAppointments />;
      case 'monitoring':
        return (
          <div className="bg-card rounded-xl p-6 shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Live Pet Monitoring</h2>
            <p className="text-muted-foreground mb-4">Watch your pets in real-time while they're staying with us.</p>
            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
              <p className="text-muted-foreground">Live feed will appear here</p>
            </div>
            <p className="text-sm text-muted-foreground">Please note: Live monitoring is only available for pets currently boarding with us.</p>
          </div>
        );
      // Add other cases for remaining tabs
      default:
        return (
          <div className="bg-card rounded-xl p-6 shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Coming Soon</h2>
            <p className="text-muted-foreground">This feature is currently under development.</p>
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-24 pb-20 px-4">
        <div className="container mx-auto">
          <DashboardHeader />
          
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
            <DashboardSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
            
            <div className="lg:col-span-3 space-y-8">
              {renderActiveContent()}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </motion.div>
  );
};

export default Dashboard;
