
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Heart, Award, Clock, ShieldCheck, Users, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';

const About = () => {
  useEffect(() => {
    document.title = "About Us | The Pet Retreat";
    window.scrollTo(0, 0);
  }, []);

  const values = [
    {
      icon: <Heart className="h-8 w-8 text-petretreat-coral" />,
      title: "Compassionate Care",
      description: "We treat every pet as if they were our own, with love, patience and respect."
    },
    {
      icon: <Award className="h-8 w-8 text-petretreat-orange" />,
      title: "Excellence",
      description: "We maintain the highest standards in veterinary care and customer service."
    },
    {
      icon: <Clock className="h-8 w-8 text-petretreat-teal" />,
      title: "Reliability",
      description: "We're there when you need us, with 24/7 emergency services and consistent care."
    },
    {
      icon: <ShieldCheck className="h-8 w-8 text-petretreat-purple" />,
      title: "Safety",
      description: "Your pet's wellbeing is our top priority in everything we do."
    },
    {
      icon: <Users className="h-8 w-8 text-petretreat-blue" />,
      title: "Community",
      description: "We build lasting relationships with pet owners and the community we serve."
    },
    {
      icon: <Smile className="h-8 w-8 text-petretreat-cream" />,
      title: "Happiness",
      description: "We believe in creating joyful experiences for pets and their owners."
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <section className="py-20">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-16">
              <div className="inline-block rounded-full bg-petretreat-teal/20 px-3 py-1 text-sm font-medium text-petretreat-teal mb-3">
                Our Story
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-shadow">
                About The Pet Retreat
              </h1>
              <p className="text-lg text-petretreat-lightGray max-w-3xl mx-auto">
                A luxury pet care center dedicated to providing the highest quality services for your beloved furry family members.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <div className="order-2 md:order-1">
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Our Mission</h2>
                <p className="text-petretreat-lightGray mb-5">
                  At The Pet Retreat, we believe every pet deserves exceptional care. Our mission is to provide comprehensive, compassionate care that enriches the lives of pets and strengthens the bond they share with their families.
                </p>
                <p className="text-petretreat-lightGray mb-5">
                  Founded in 2015, The Pet Retreat has grown from a small veterinary practice to a full-service pet care center offering veterinary care, boarding, grooming, training, and retail services under one roof.
                </p>
                <p className="text-petretreat-lightGray mb-8">
                  Our team consists of experienced veterinarians, certified groomers, professional trainers, and animal care specialists who share a deep passion for pet welfare and the highest standards of professional care.
                </p>
                <Button className="bg-petretreat-coral hover:bg-petretreat-coral/90 text-white">
                  Meet Our Team
                </Button>
              </div>
              <div className="order-1 md:order-2 glass-morphism rounded-2xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1612531385446-f7e6d131e1d0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80" 
                  alt="The Pet Retreat Center" 
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
            </div>
            
            <div className="mb-16">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-8 text-center">Our Values</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {values.map((value, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="neo-card rounded-xl p-6"
                  >
                    <div className="bg-petretreat-darkCharcoal p-3 rounded-full inline-flex mb-4 neo-button">
                      {value.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{value.title}</h3>
                    <p className="text-petretreat-lightGray">{value.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </motion.div>
  );
};

export default About;
