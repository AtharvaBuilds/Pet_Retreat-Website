
import { useEffect } from 'react';
import { motion } from 'framer-motion';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BookingForm from '@/components/booking/BookingForm';

const Booking = () => {
  useEffect(() => {
    document.title = "Book a Service | The Pet Retreat";
    window.scrollTo(0, 0);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-24 pb-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Book Your Pet's Experience
            </h1>
            <p className="text-white/80 max-w-2xl mx-auto">
              Schedule an appointment for any of our premium pet care services. 
              Our team will confirm your booking and provide any additional information needed.
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="bg-petretreat-slate/30 backdrop-filter backdrop-blur-md border border-petretreat-purple/20 rounded-2xl p-6 md:p-8"
          >
            <BookingForm />
          </motion.div>
        </div>
      </main>
      <Footer />
    </motion.div>
  );
};

export default Booking;
