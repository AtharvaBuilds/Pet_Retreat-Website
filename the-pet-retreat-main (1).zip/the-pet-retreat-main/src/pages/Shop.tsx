
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ShoppingCart, Package, Gift, Tag, Truck, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Shop = () => {
  useEffect(() => {
    document.title = "Pet Shop | The Pet Retreat";
    window.scrollTo(0, 0);
  }, []);

  const productCategories = [
    { icon: <ShoppingCart className="h-8 w-8" />, name: "All Products", count: 120 },
    { icon: <Package className="h-8 w-8" />, name: "Food & Treats", count: 48 },
    { icon: <Gift className="h-8 w-8" />, name: "Toys & Accessories", count: 36 },
    { icon: <Tag className="h-8 w-8" />, name: "Grooming Supplies", count: 24 },
    { icon: <Truck className="h-8 w-8" />, name: "Travel Essentials", count: 18 },
    { icon: <CreditCard className="h-8 w-8" />, name: "Special Offers", count: 12 },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen flex flex-col overflow-hidden bg-gradient-dark"
    >
      <Navbar />
      <main className="flex-grow pt-24 pb-20">
        <section className="py-20">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="text-center mb-16">
              <div className="inline-block rounded-full bg-petretreat-purple/20 px-3 py-1 text-sm font-medium text-petretreat-purple mb-3">
                Premium Pet Products
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-shadow">
                The Pet Retreat Shop
              </h1>
              <p className="text-lg text-petretreat-lightGray max-w-3xl mx-auto">
                Browse our selection of premium pet products, from food and toys to grooming supplies and accessories.
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6 mb-16">
              {productCategories.map((category, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="neo-card rounded-xl p-4 hover:scale-105 transition-all cursor-pointer"
                >
                  <div className="bg-petretreat-purple/20 p-3 rounded-full inline-flex mb-3">
                    <div className="text-petretreat-purple">{category.icon}</div>
                  </div>
                  <h3 className="font-semibold text-lg text-white mb-1">{category.name}</h3>
                  <p className="text-sm text-petretreat-lightGray/70">{category.count} items</p>
                </motion.div>
              ))}
            </div>
            
            <div className="glass-morphism p-8 rounded-2xl mb-16">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="text-left md:max-w-xl">
                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                    Shop Coming Soon!
                  </h2>
                  <p className="text-petretreat-lightGray mb-6">
                    We're currently setting up our online store to bring you the best selection of premium pet products. Sign up to be notified when we launch and get exclusive early access to our special offers.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button className="bg-petretreat-purple hover:bg-petretreat-purple/90 text-white">
                      Notify Me
                    </Button>
                    <Button variant="outline" className="border-petretreat-purple/50 text-petretreat-purple hover:bg-petretreat-purple/10">
                      Learn More
                    </Button>
                  </div>
                </div>
                <div className="w-full md:w-1/3 animate-float">
                  <img 
                    src="https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2338&q=80" 
                    alt="Premium Pet Products" 
                    className="rounded-xl shadow-2xl"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </motion.div>
  );
};

export default Shop;
